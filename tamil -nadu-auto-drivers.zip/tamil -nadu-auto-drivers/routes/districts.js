// routes/districts.js
const express = require("express");
const router = express.Router();
const districts = require("../data/districts.json");

router.get("/", (_req, res) => {
  res.json(districts);
});

module.exports = router;
