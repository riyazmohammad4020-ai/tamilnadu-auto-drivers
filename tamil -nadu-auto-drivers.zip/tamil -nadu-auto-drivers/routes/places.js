// routes/places.js
const express = require("express");
const router = express.Router();
const places = require("../data/places.json");

router.get("/:district", (req, res) => {
  const d = decodeURIComponent(req.params.district);
  const list = places[d];
  if (!list) return res.status(404).json({ error: "District not found" });
  res.json({ district: d, places: list });
});

module.exports = router;
