// routes/utilities.js
const express = require("express");
const router = express.Router();
const places = require("../data/places.json");
const fares = require("../data/fares.json");

const PETROL_PRICE = parseFloat(process.env.PETROL_PRICE || "106.0");

router.get("/petrol-price", (_req, res) => {
  res.json({ price: PETROL_PRICE });
});

router.get("/fare-config", (_req, res) => {
  res.json(fares);
});

function findPlaceById(id) {
  for (const d in places) {
    const match = places[d].find((p) => p.id === id);
    if (match) return match;
  }
  return null;
}

function haversine(lat1, lon1, lat2, lon2) {
  const R = 6371; // km
  const toRad = (deg) => (deg * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

// Mock nearest essentials per district using place anchors
router.get("/nearby/:placeId", (req, res) => {
  const placeId = decodeURIComponent(req.params.placeId);
  const base = findPlaceById(placeId);
  if (!base) return res.status(404).json({ error: "Place not found" });

  // Sample points near base (mocked offsets)
  const candidates = [
    { type: "police", name: "District Police Station", lat: base.lat + 0.02, lng: base.lng + 0.01, desc: "Main station for public safety" },
    { type: "hospital", name: "General Hospital", lat: base.lat - 0.01, lng: base.lng + 0.015, desc: "24x7 emergency care" },
    { type: "school", name: "Govt Higher Secondary School", lat: base.lat + 0.008, lng: base.lng - 0.012, desc: "Public education facility" },
    { type: "toll", name: "NH Toll Plaza", lat: base.lat - 0.018, lng: base.lng - 0.017, desc: "National Highway toll gate" },
    { type: "office", name: "Collectorate", lat: base.lat + 0.012, lng: base.lng + 0.02, desc: "District administrative office" }
  ];

  const nearby = candidates.map((c) => ({
    ...c,
    km: haversine(base.lat, base.lng, c.lat, c.lng)
  })).sort((a, b) => a.km - b.km);

  res.json({ base: { id: base.id, name: base.name }, nearby });
});

module.exports = router;
