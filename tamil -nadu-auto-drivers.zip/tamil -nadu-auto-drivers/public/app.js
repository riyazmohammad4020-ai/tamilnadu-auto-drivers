// public/app.js

const $ = (id) => document.getElementById(id);

const fromDistrictEl = $("fromDistrict");
const toDistrictEl = $("toDistrict");
const fromPlaceEl = $("fromPlace");
const toPlaceEl = $("toPlace");

const distanceKmEl = $("distanceKm");
const fuelNeededEl = $("fuelNeeded");
const fuelCostEl = $("fuelCost");
const fareSuggestEl = $("fareSuggest");

const manualFromKmEl = $("manualFromKm");
const manualToKmEl = $("manualToKm");
const manualDistanceEl = $("manualDistance");
const manualFuelEl = $("manualFuel");
const manualCostEl = $("manualCost");

const mileageEl = $("mileage");
const petrolPriceEl = $("petrolPrice");

const calcDistanceBtn = $("calcDistanceBtn");
const calcFuelBtn = $("calcFuelBtn");
const calcManualBtn = $("calcManualBtn");
const findGovtBtn = $("findGovtBtn");
const toggleThemeBtn = $("toggleThemeBtn");

// Emoji maps for districts
const districtEmojis = {
  "Chennai": "🏙",
  "Kanyakumari": "🌴",
  "Madurai": "🛕",
  "Coimbatore": "🏬",
  "Tiruchirappalli": "🏛",
  "Salem": "⛰",
  "Erode": "🧵",
  "Tirunelveli": "🌊",
  "Thoothukudi": "⚓",
  "Dindigul": "🥭",
  "Krishnagiri": "🪨",
  "Dharmapuri": "🌾",
  "Vellore": "🏰",
  "Ranipet": "🪙",
  "Tirupathur": "🧱",
  "Tiruvannamalai": "🛕",
  "Kanchipuram": "🕍",
  "Chengalpattu": "🏖",
  "Thiruvallur": "🏗",
  "Ariyalur": "🧱",
  "Perambalur": "🌾",
  "Cuddalore": "🏝",
  "Nagapattinam": "🐚",
  "Mayiladuthurai": "🦚",
  "Tiruvarur": "🛶",
  "Thanjavur": "🎨",
  "Karur": "🧵",
  "Namakkal": "🚚",
  "The Nilgiris": "🏞",
  "Tenkasi": "⛲",
  "Sivagangai": "⚔️",
  "Ramanathapuram": "🕌",
  "Pudukkottai": "🏯",
  "Virudhunagar": "🎇",
  "Theni": "🍵",
  "Nilgiris": "🏞",            // alias safeguard
  "Kallakurichi": "🌿",
  "Viluppuram": "🛣",
  "Karaikal": "🏖"            // if ever extended
};

const placeEmojisByType = {
  temple: "🛕",
  nature: "🏞",
  city: "🏬",
  bus: "🚏",
  stadium: "🏟",
  market: "🛍",
  fort: "🏰",
  museum: "🏛",
  port: "⚓",
  beach: "🏖",
  dam: "💧"
};

// Load initial data
async function init() {
  await loadPetrolPrice();
  const districts = await fetchJSON("/api/districts");
  populateDistricts(districts);
  attachListeners();
}

function attachListeners() {
  fromDistrictEl.addEventListener("change", () => loadPlaces("from"));
  toDistrictEl.addEventListener("change", () => loadPlaces("to"));
  calcDistanceBtn.addEventListener("click", calculateDistance);
  calcFuelBtn.addEventListener("click", calculateFuel);
  calcManualBtn.addEventListener("click", calculateManual);
  findGovtBtn.addEventListener("click", findNearestGovt);
  toggleThemeBtn.addEventListener("click", toggleTheme);
}

function toggleTheme() {
  const isLight = document.documentElement.classList.toggle("light");
  toggleThemeBtn.textContent = isLight ? "🌙 Dark Mode" : "🌓 Toggle Theme";
}

async function loadPetrolPrice() {
  try {
    const res = await fetchJSON("/api/utilities/petrol-price");
    petrolPriceEl.value = res.price.toFixed(2);
  } catch (e) {
    petrolPriceEl.placeholder = "Enter current price";
  }
}

function districtLabel(d) {
  const emoji = districtEmojis[d] || "🛣";
  return `${emoji} ${d}`;
}

function populateDistricts(districts) {
  // Fill FROM and TO
  [fromDistrictEl, toDistrictEl].forEach((sel) => {
    sel.innerHTML = `<option value="">Select district</option>`;
    districts.forEach((d) => {
      const opt = document.createElement("option");
      opt.value = d;
      opt.textContent = districtLabel(d);
      sel.appendChild(opt);
    });
  });
}

async function loadPlaces(which) {
  const district = (which === "from" ? fromDistrictEl.value : toDistrictEl.value);
  const target = which === "from" ? fromPlaceEl : toPlaceEl;
  target.innerHTML = `<option value="">Loading...</option>`;
  if (!district) {
    target.innerHTML = `<option value="">Select district first</option>`;
    return;
  }
  try {
    const res = await fetchJSON(`/api/places/${encodeURIComponent(district)}`);
    target.innerHTML = `<option value="">Select place</option>`;
    res.places.forEach((p) => {
      const emoji = placeEmojisByType[p.type] || "📍";
      const opt = document.createElement("option");
      opt.value = p.id;
      opt.textContent = `${emoji} ${p.name}`;
      opt.dataset.lat = p.lat;
      opt.dataset.lng = p.lng;
      target.appendChild(opt);
    });
  } catch (e) {
    target.innerHTML = `<option value="">No places</option>`;
  }
}

async function calculateDistance() {
  const fromId = fromPlaceEl.value;
  const toId = toPlaceEl.value;
  if (!fromId || !toId) {
    alert("Please select both FROM and TO places.");
    return;
  }
  try {
    const res = await fetchJSON(`/api/distance?from=${encodeURIComponent(fromId)}&to=${encodeURIComponent(toId)}`);
    distanceKmEl.textContent = res.km.toFixed(2);
    // Also update fuel card instantly if mileage and price present
    autoUpdateFuelFromDistance(res.km);
  } catch (e) {
    alert("Could not calculate distance. Try again.");
  }
}

function autoUpdateFuelFromDistance(km) {
  const mileage = parseFloat(mileageEl.value);
  const price = parseFloat(petrolPriceEl.value);
  if (!isFinite(km) || !isFinite(mileage) || mileage <= 0 || !isFinite(price)) return;
  const fuel = km / mileage;
  const cost = fuel * price;
  const fare = suggestFare(km, cost);
  fuelNeededEl.textContent = fuel.toFixed(2);
  fuelCostEl.textContent = cost.toFixed(2);
  fareSuggestEl.textContent = fare.toFixed(0);
}

function suggestFare(km, fuelCost) {
  // Simple model: base fare + per-km + fuel buffer
  // Config defaults served by /api/utilities/fare-config
  return window.fareCfg
    ? (window.fareCfg.base + km * window.fareCfg.perKm + fuelCost * window.fareCfg.fuelBuffer)
    : (30 + km * 12 + fuelCost * 1.2);
}

async function calculateFuel() {
  const km = parseFloat(distanceKmEl.textContent);
  if (!isFinite(km)) {
    alert("Calculate distance first.");
    return;
  }
  const mileage = parseFloat(mileageEl.value);
  const price = parseFloat(petrolPriceEl.value);
  if (!isFinite(mileage) || mileage <= 0 || !isFinite(price)) {
    alert("Enter valid mileage and petrol price.");
    return;
  }
  const fuel = km / mileage;
  const cost = fuel * price;
  const fare = suggestFare(km, cost);
  fuelNeededEl.textContent = fuel.toFixed(2);
  fuelCostEl.textContent = cost.toFixed(2);
  fareSuggestEl.textContent = fare.toFixed(0);
}

async function calculateManual() {
  const fromKm = parseFloat(manualFromKmEl.value);
  const toKm = parseFloat(manualToKmEl.value);
  const mileage = parseFloat(mileageEl.value);
  const price = parseFloat(petrolPriceEl.value);

  if (!isFinite(fromKm) || !isFinite(toKm)) {
    alert("Enter valid KM markers.");
    return;
  }
  const dist = Math.abs(toKm - fromKm);
  manualDistanceEl.textContent = dist.toFixed(2);

  if (isFinite(mileage) && mileage > 0 && isFinite(price)) {
    const fuel = dist / mileage;
    const cost = fuel * price;
    manualFuelEl.textContent = fuel.toFixed(2);
    manualCostEl.textContent = cost.toFixed(2);
  } else {
    manualFuelEl.textContent = "—";
    manualCostEl.textContent = "—";
  }
}

async function findNearestGovt() {
  const placeId = toPlaceEl.value || fromPlaceEl.value;
  if (!placeId) {
    alert("Select a place first.");
    return;
  }
  try {
    const res = await fetchJSON(`/api/utilities/nearby/${encodeURIComponent(placeId)}`);
    renderGovt(res.nearby);
  } catch (e) {
    alert("Could not fetch nearby essentials.");
  }
}

function renderGovt(items) {
  const wrap = $("govtList");
  wrap.innerHTML = "";
  const iconMap = {
    police: "🚓",
    hospital: "🏥",
    school: "🏫",
    toll: "🛣",
    office: "🏢"
  };
  items.forEach((it) => {
    const div = document.createElement("div");
    div.className = "govt-card";
    div.innerHTML = `
      <div class="title">${iconMap[it.type] || "🏢"} ${it.name}</div>
      <div class="muted">${it.desc || "—"}</div>
      <div class="muted">📏 ${it.km.toFixed(2)} KM away</div>
    `;
    wrap.appendChild(div);
  });
}

async function fetchFareCfg() {
  try {
    const res = await fetchJSON("/api/utilities/fare-config");
    window.fareCfg = res;
  } catch {}
}

async function fetchJSON(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error("Network error");
  return res.json();
}

window.addEventListener("DOMContentLoaded", async () => {
  await init();
  await fetchFareCfg();
});
